export function MomentPanel({ id, moment, currentIndex, total, answer, note, onAnswer, onNote, onPrev, onNext, completed }) {
  return (
    <section id={id} className="card panel">
      <div className="section-head">
        <div>
          <p className="label">Aktueller Moment</p>
          <h2>{moment.time} · {moment.title}</h2>
        </div>
        <span className="pill">{completed} erledigt</span>
      </div>
      <p className="prompt">{moment.prompt}</p>
      <div className="option-grid">
        {moment.options.map((option) => (
          <button key={option} className={`option-card ${answer === option ? 'active' : ''}`} onClick={() => onAnswer(option)}>
            <strong>{option}</strong>
            <span>1-Klick-Auswahl</span>
          </button>
        ))}
      </div>
      <div className="ai-card">
        <p className="label">Spontane Reflexion</p>
        <h3>{moment.question}</h3>
        <div className="chip-row">
          {moment.chips.map((chip) => (
            <button key={chip} className="chip" onClick={() => onNote(note ? `${note} · ${chip}` : chip)}>{chip}</button>
          ))}
        </div>
        <textarea className="note" value={note} onChange={(e) => onNote(e.target.value)} placeholder="Kurze Beobachtung notieren..." />
      </div>
      <div className="panel-actions">
        <button className="btn btn-secondary" onClick={onPrev} disabled={currentIndex === 0}>Zurück</button>
        <button className="btn btn-primary" onClick={onNext} disabled={currentIndex === total - 1}>Weiter</button>
      </div>
    </section>
  )
}
