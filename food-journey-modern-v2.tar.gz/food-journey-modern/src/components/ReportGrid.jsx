export function ReportGrid({ id, report, progress, onReset }) {
  const items = [
    ['Rhythmus-Resonanz', report.archetype],
    ['Biologischer Takt', report.timing],
    ['Hebel für morgen', report.action],
    ['Tagesabschluss', report.closing]
  ]

  return (
    <section id={id} className="report-wrap">
      <div className="report-top card">
        <div>
          <p className="label">Tagesbild</p>
          <h2>Reduzierter Report mit Fokus auf das Wesentliche.</h2>
          <p className="report-copy">Statt einer textlastigen Analyse zeigt die App nur das, was du morgen wirklich gebrauchen kannst.</p>
        </div>
        <div className="report-side">
          <div className="progress-ring"><span>{progress}%</span></div>
          <button className="btn btn-secondary" onClick={onReset}>Tag zurücksetzen</button>
        </div>
      </div>
      <div className="report-grid">
        {items.map(([label, value]) => (
          <article key={label} className="card report-card">
            <p className="label">{label}</p>
            <h3>{value}</h3>
            <p>Eine knappe Interpretation mit bewusst reduzierter Informationsdichte.</p>
          </article>
        ))}
      </div>
    </section>
  )
}
