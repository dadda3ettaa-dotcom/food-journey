export function Sidebar({ moments, currentIndex, answers, onJump }) {
  const completed = answers.filter(Boolean).length
  return (
    <aside className="sidebar card">
      <div className="section-head">
        <div>
          <p className="label">Heute</p>
          <h2>9 Momente</h2>
        </div>
        <span className="pill">{completed} / {moments.length}</span>
      </div>
      <div className="progress"><span style={{ width: `${Math.max(10, (completed / moments.length) * 100)}%` }} /></div>
      <div className="moment-list">
        {moments.map((moment, i) => (
          <button key={moment.time} className={`moment-nav ${i === currentIndex ? 'active' : ''}`} onClick={() => onJump(i)}>
            <div>
              <strong>{moment.time} · {moment.title}</strong>
              <small>{moment.prompt}</small>
            </div>
            <span className={`status ${answers[i] ? 'done' : ''}`} />
          </button>
        ))}
      </div>
    </aside>
  )
}
