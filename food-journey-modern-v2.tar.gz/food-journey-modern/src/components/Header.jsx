export function Header({ theme, toggleTheme }) {
  return (
    <header className="header">
      <div className="brand">
        <svg viewBox="0 0 64 64" className="logo" aria-label="Food Journey Logo" role="img">
          <path d="M16 41c0-12 7-22 16-22s16 10 16 22" stroke="currentColor" strokeWidth="4" strokeLinecap="round" fill="none" />
          <path d="M24 22c1-7 6-12 8-12 2 0 7 5 8 12" stroke="currentColor" strokeWidth="4" strokeLinecap="round" fill="none" />
          <circle cx="32" cy="41" r="7" fill="currentColor" opacity=".18" />
          <path d="M29 41h6" stroke="currentColor" strokeWidth="4" strokeLinecap="round" fill="none" />
        </svg>
        <div>
          <strong>Food Journey</strong>
          <span>modern · ruhig · fokussiert</span>
        </div>
      </div>
      <button className="icon-btn" onClick={toggleTheme} aria-label="Theme wechseln">
        {theme === 'dark' ? '☀' : '☾'}
      </button>
    </header>
  )
}
