import { useEffect, useMemo, useState } from 'react'
import { moments } from './data'
import { Header } from './components/Header'
import { Sidebar } from './components/Sidebar'
import { MomentPanel } from './components/MomentPanel'
import { ReportGrid } from './components/ReportGrid'

const STORAGE_KEY = 'food-journey-modern-v1'

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return null
    return JSON.parse(raw)
  } catch {
    return null
  }
}

export default function App() {
  const [theme, setTheme] = useState(window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
  const persisted = loadState()
  const [index, setIndex] = useState(persisted?.index ?? 0)
  const [answers, setAnswers] = useState(persisted?.answers ?? Array(moments.length).fill(''))
  const [notes, setNotes] = useState(persisted?.notes ?? Array(moments.length).fill(''))

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ index, answers, notes }))
  }, [index, answers, notes])

  const current = moments[index]
  const completed = answers.filter(Boolean).length
  const progress = Math.round((completed / moments.length) * 100)

  const report = useMemo(() => {
    const values = answers.filter(Boolean)
    const calm = values.some(v => /klar|ruhig|stabil|ausgewogen|gut|passend/i.test(v))
    const stress = values.some(v => /stress|spannung|impulsiv|nebenbei|zeitdruck|digital|müde/i.test(v))
    const evening = values.some(v => /ruhig|ausgeglichen/i.test(v))
    return {
      archetype: calm ? 'Ruhiger Rhythmus mit bewussten Entscheidungen' : 'Tag mit wechselnden Körpersignalen',
      timing: completed >= 4 ? 'Essfenster und Energieverlauf sind jetzt besser erkennbar' : 'Noch wenig Daten, aber erste Muster sind sichtbar',
      action: stress ? 'Beim nächsten Impuls 60 Sekunden warten und erst dann entscheiden' : 'Den ruhigsten Moment morgen bewusst wiederholen',
      closing: evening ? 'Dein Abend wirkt reguliert und eher bewusst abgeschlossen.' : 'Am Abend lohnt sich ein klareres Ritual statt automatischer Reize.'
    }
  }, [answers, completed])

  const updateAnswer = (value) => {
    const next = [...answers]
    next[index] = value
    setAnswers(next)
  }

  const updateNote = (value) => {
    const next = [...notes]
    next[index] = value
    setNotes(next)
  }

  const jump = (target) => setIndex(Math.max(0, Math.min(moments.length - 1, target)))
  const resetDay = () => {
    setIndex(0)
    setAnswers(Array(moments.length).fill(''))
    setNotes(Array(moments.length).fill(''))
  }

  return (
    <div className="app" data-theme={theme}>
      <a className="skip-link" href="#main">Zum Inhalt springen</a>
      <div className="shell">
        <Header theme={theme} toggleTheme={() => setTheme(theme === 'dark' ? 'light' : 'dark')} />

        <section className="hero card">
          <div className="hero-copy-block">
            <p className="eyebrow">Modernisierte Web-App</p>
            <h1>Weniger Text. Mehr Fokus. Ein ruhiger Blick auf deinen Tag.</h1>
            <p className="hero-copy">Die App verdichtet die sichtbare Food-Journey-Idee aus AI Studio zu einer moderneren, klareren Oberfläche: Tagesmomente erfassen, Signale verstehen, Report lesen.</p>
            <div className="hero-actions">
              <button className="btn btn-primary" onClick={() => document.getElementById('moment-panel')?.scrollIntoView({ behavior: 'smooth' })}>Jetzt starten</button>
              <button className="btn btn-secondary" onClick={() => document.getElementById('report-grid')?.scrollIntoView({ behavior: 'smooth' })}>Report ansehen</button>
            </div>
            <div className="hero-stats">
              <div><strong>9</strong><span>Tagesmomente</span></div>
              <div><strong>{progress}%</strong><span>erfasst</span></div>
              <div><strong>0 €</strong><span>Hosting via GitHub Pages</span></div>
            </div>
          </div>
          <div className="hero-panel">
            <div className="glass-stack">
              <div className="glass-card accent">
                <span>Heute</span>
                <strong>{current.time} · {current.title}</strong>
                <p>{current.prompt}</p>
              </div>
              <div className="glass-grid">
                {moments.map((moment, i) => (
                  <button key={moment.time} className={`micro-card ${answers[i] ? 'done' : ''}`} onClick={() => jump(i)}>
                    <strong>{moment.time}</strong>
                    <span>{moment.title}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="feature-strip">
          <article className="card feature-card">
            <p className="label">01</p>
            <h2>Kompakte Fokus-Zentrale</h2>
            <p>Eine klare Startfläche bündelt Status, Fortschritt und direkten Einstieg in den aktuellen Moment.</p>
          </article>
          <article className="card feature-card">
            <p className="label">02</p>
            <h2>1-Klick-Momente</h2>
            <p>Antworten werden schnell erfasst, ohne Reibung und ohne textliche Überladung.</p>
          </article>
          <article className="card feature-card">
            <p className="label">03</p>
            <h2>Ruhiger Report</h2>
            <p>Am Ende bleiben drei bis vier klare Signale statt eine überladene Auswertung.</p>
          </article>
        </section>

        <main id="main" className="layout">
          <Sidebar moments={moments} currentIndex={index} answers={answers} onJump={jump} />
          <div className="main-column">
            <MomentPanel
              id="moment-panel"
              moment={current}
              currentIndex={index}
              total={moments.length}
              answer={answers[index]}
              note={notes[index]}
              onAnswer={updateAnswer}
              onNote={updateNote}
              onPrev={() => jump(index - 1)}
              onNext={() => jump(index + 1)}
              completed={completed}
            />
            <ReportGrid id="report-grid" report={report} progress={progress} onReset={resetDay} />
          </div>
        </main>
      </div>
    </div>
  )
}
